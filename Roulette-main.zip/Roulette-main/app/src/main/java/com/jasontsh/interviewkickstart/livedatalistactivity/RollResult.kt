package com.jasontsh.interviewkickstart.livedatalistactivity

data class RollResult(val roll: Int, val result: Int)